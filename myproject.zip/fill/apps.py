from django.apps import AppConfig


class FillConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fill'
